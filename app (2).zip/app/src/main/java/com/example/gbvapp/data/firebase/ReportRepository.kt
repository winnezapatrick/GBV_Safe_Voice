package com.example.gbvapp.data.firebase

import android.net.Uri
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class ReportDetailModel(
    val reference: String,
    val category: String,
    val description: String,
    val location: String,
    val reportingFor: String,
    val evidenceUrls: List<String>,
    val status: String = "Pending",
    val assignedOfficerId: String? = null,
    val assignedOfficerName: String? = null,
    val assignedAt: Any? = null,
    val submissionTimestamp: Any? = null,
    val lastUpdatedAt: Any? = null,
    val urgencyLevel: String = "Normal",
    val observations: String = ""
)

data class AnalyticsSummary(
    val totalSubmitted: Int = 0,
    val pendingReports: Int = 0,
    val reportsUnderReview: Int = 0,
    val resolvedCases: Int = 0,
    val closedCases: Int = 0,
    val totalOfficers: Int = 0,
    val categoryCounts: Map<String, Int> = emptyMap(),
    val anonymousCount: Int = 0,
    val identifiedCount: Int = 0
)

object ReportRepository {

    suspend fun uploadEvidence(fileUri: Uri): String {
        val fileName = "evidence_${UUID.randomUUID()}.jpg"
        val storageRef: StorageReference = FirebaseManager.storage.reference.child("evidence/$fileName")
        storageRef.putFile(fileUri).await()
        return storageRef.downloadUrl.await().toString()
    }

    suspend fun submitReport(
        category: String,
        description: String,
        location: String,
        reportingFor: String,
        evidenceUris: List<Uri>
    ): String {
        val referenceNumber = "SV-2026-" + (1000..9999).random()
        
        val evidenceUrls = mutableListOf<String>()
        for (uri in evidenceUris) {
            try {
                val url = uploadEvidence(uri)
                evidenceUrls.add(url)
            } catch (_: Exception) {
                // Fallback / ignore failed optional evidence upload
            }
        }

        val isAnonymous = reportingFor.equals("Myself", ignoreCase = true) || reportingFor.contains("Anonymous", ignoreCase = true)

        val reportData = hashMapOf(
            "reference" to referenceNumber,
            "category" to category,
            "description" to description,
            "location" to location,
            "reportingFor" to reportingFor,
            "isAnonymous" to isAnonymous,
            "evidenceUrls" to evidenceUrls,
            "status" to "Pending",
            "assignedOfficerId" to null,
            "assignedOfficerName" to null,
            "submissionTimestamp" to FieldValue.serverTimestamp(),
            "lastUpdatedAt" to FieldValue.serverTimestamp()
        )

        FirebaseManager.firestore.collection("reports")
            .document(referenceNumber)
            .set(reportData)
            .await()

        // Log audit
        CaseManagementRepository.logAudit(
            action = "REPORT_SUBMITTED",
            category = category,
            performedBy = "Student (Public)",
            targetId = referenceNumber,
            details = "New GBV report submitted successfully."
        )

        return referenceNumber
    }

    suspend fun assignReport(reference: String, officerId: String, officerName: String, adminName: String = "Admin"): Boolean {
        return try {
            val updates = hashMapOf<String, Any?>(
                "assignedOfficerId" to officerId,
                "assignedOfficerName" to officerName,
                "assignedAt" to FieldValue.serverTimestamp(),
                "status" to "Assigned",
                "lastUpdatedAt" to FieldValue.serverTimestamp()
            )

            FirebaseManager.firestore.collection("reports")
                .document(reference)
                .update(updates)
                .await()

            CaseManagementRepository.logAudit(
                action = "REPORT_ASSIGNED",
                category = "Assignment",
                performedBy = adminName,
                targetId = reference,
                details = "Assigned case $reference to Officer $officerName ($officerId)."
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getAllReports(): List<ReportDetailModel> {
        return try {
            val snapshot = FirebaseManager.firestore.collection("reports")
                .orderBy("submissionTimestamp", Query.Direction.DESCENDING)
                .get()
                .await()

            snapshot.documents.mapNotNull { parseReportDoc(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getAssignedReportsForOfficer(officerId: String): List<ReportDetailModel> {
        return try {
            val snapshot = FirebaseManager.firestore.collection("reports")
                .whereEqualTo("assignedOfficerId", officerId)
                .get()
                .await()

            snapshot.documents.mapNotNull { parseReportDoc(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getAnalyticsSummary(): AnalyticsSummary {
        return try {
            val reportsSnapshot = FirebaseManager.firestore.collection("reports").get().await()
            val officersSnapshot = FirebaseManager.firestore.collection("officers").get().await()

            var totalSubmitted = 0
            var pendingReports = 0
            var reportsUnderReview = 0
            var resolvedCases = 0
            var closedCases = 0
            var anonymousCount = 0
            var identifiedCount = 0
            val categoryCounts = mutableMapOf<String, Int>()

            for (doc in reportsSnapshot.documents) {
                totalSubmitted++
                val status = doc.getString("status") ?: "Pending"
                val category = doc.getString("category") ?: "Other"
                val reportingFor = doc.getString("reportingFor") ?: "Myself"
                val isAnonymous = doc.getBoolean("isAnonymous") ?: (reportingFor.contains("Myself", ignoreCase = true))

                if (isAnonymous) anonymousCount++ else identifiedCount++

                categoryCounts[category] = (categoryCounts[category] ?: 0) + 1

                when (status.lowercase()) {
                    "pending" -> pendingReports++
                    "under review" -> reportsUnderReview++
                    "assigned" -> pendingReports++
                    "resolved" -> resolvedCases++
                    "closed" -> closedCases++
                }
            }

            val totalOfficers = officersSnapshot.size()

            AnalyticsSummary(
                totalSubmitted = totalSubmitted,
                pendingReports = pendingReports,
                reportsUnderReview = reportsUnderReview,
                resolvedCases = resolvedCases,
                closedCases = closedCases,
                totalOfficers = totalOfficers,
                categoryCounts = categoryCounts,
                anonymousCount = anonymousCount,
                identifiedCount = identifiedCount
            )
        } catch (_: Exception) {
            AnalyticsSummary()
        }
    }

    private fun parseReportDoc(doc: DocumentSnapshot): ReportDetailModel? {
        val ref = doc.getString("reference") ?: doc.id
        val cat = doc.getString("category") ?: "GBV Incident"
        val desc = doc.getString("description") ?: ""
        val loc = doc.getString("location") ?: "Not specified"
        val repFor = doc.getString("reportingFor") ?: "Myself"
        @Suppress("UNCHECKED_CAST")
        val evUrls = doc.get("evidenceUrls") as? List<String> ?: emptyList()
        val status = doc.getString("status") ?: "Pending"
        val assignedOfficerId = doc.getString("assignedOfficerId")
        val assignedOfficerName = doc.getString("assignedOfficerName")
        val assignedAt = doc.get("assignedAt")
        val subTimestamp = doc.get("submissionTimestamp")
        val lastUpdate = doc.get("lastUpdatedAt")
        val urgency = doc.getString("urgencyLevel") ?: "Normal"
        val obs = doc.getString("observations") ?: ""

        return ReportDetailModel(
            reference = ref,
            category = cat,
            description = desc,
            location = loc,
            reportingFor = repFor,
            evidenceUrls = evUrls,
            status = status,
            assignedOfficerId = assignedOfficerId,
            assignedOfficerName = assignedOfficerName,
            assignedAt = assignedAt,
            submissionTimestamp = subTimestamp,
            lastUpdatedAt = lastUpdate,
            urgencyLevel = urgency,
            observations = obs
        )
    }
}
