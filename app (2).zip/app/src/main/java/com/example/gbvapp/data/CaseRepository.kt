package com.example.gbvapp.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import com.example.gbvapp.data.backend.SafeVoiceDatabaseHelper

enum class CaseStatus {
    Assigned, Open, Resolved, Closed
}

data class CaseItem(
    val reference: String,
    val category: String,
    val location: String,
    val dateReported: String,
    val description: String,
    val evidenceAttachments: List<String>,
    var status: CaseStatus,
    val submissionDate: String,
    var closureDate: String? = null
)

object CaseRepository {
    val cases = mutableStateListOf<CaseItem>()
    private var dbHelper: SafeVoiceDatabaseHelper? = null

    fun init(context: Context) {
        if (dbHelper == null) {
            dbHelper = SafeVoiceDatabaseHelper(context)
            loadCasesFromDb()
        }
    }

    private fun loadCasesFromDb() {
        dbHelper?.let { helper ->
            val dbCases = helper.getAllCases()
            if (dbCases.isNotEmpty()) {
                cases.clear()
                cases.addAll(dbCases)
            }
        }
    }

    fun addCase(caseItem: CaseItem) {
        cases.add(0, caseItem)
        dbHelper?.insertOrUpdateCase(caseItem)
        dbHelper?.logAudit("Created case: ${caseItem.reference}")
    }

    init {
        // Fallback initial cases if init(context) has not been called yet
        cases.addAll(
            listOf(
                CaseItem(
                    reference = "GBV-2026-0047",
                    category = "Sexual Harassment • Immediate Response",
                    location = "Zomba Central, Near District Hospital Market",
                    dateReported = "Today, 14:30",
                    description = "Victim reported targeted harassment and physical intimidation near the local market area. Immediate support and intervention required.",
                    evidenceAttachments = listOf("Audio Recording (0:45)", "Photo Evidence.jpg"),
                    status = CaseStatus.Assigned,
                    submissionDate = "Today, 14:30"
                ),
                CaseItem(
                    reference = "GBV-2026-0042",
                    category = "Domestic Violence • Intake Handover",
                    location = "Blantyre West Transit Zone",
                    dateReported = "Yesterday, 09:15",
                    description = "Ongoing domestic dispute with risk of physical escalation. Safe shelter referral requested.",
                    evidenceAttachments = listOf("Medical Report Form.pdf"),
                    status = CaseStatus.Open,
                    submissionDate = "Yesterday, 09:15"
                ),
                CaseItem(
                    reference = "GBV-2026-0035",
                    category = "Physical Abuse • Legal Closure",
                    location = "Zomba Urban",
                    dateReported = "01/10/2026, 11:20",
                    description = "Physical assault case referred to legal aid and counseling services.",
                    evidenceAttachments = listOf("Incident Statement.pdf"),
                    status = CaseStatus.Resolved,
                    submissionDate = "01/10/2026, 11:20"
                ),
                CaseItem(
                    reference = "GBV-2026-0028",
                    category = "Economic Abuse • Counseling",
                    location = "Lilongwe Area 25",
                    dateReported = "28/09/2026, 16:00",
                    description = "Denial of financial resources and support. Counseling sessions completed.",
                    evidenceAttachments = listOf("Case Summary.pdf"),
                    status = CaseStatus.Closed,
                    submissionDate = "28/09/2026, 16:00",
                    closureDate = "30/09/2026, 10:00"
                )
            )
        )
    }

    fun getCase(reference: String): CaseItem? {
        return cases.find { it.reference == reference }
    }

    fun closeCase(reference: String, closureDate: String): Boolean {
        val caseItem = getCase(reference) ?: return false
        if (caseItem.status == CaseStatus.Closed) return false
        caseItem.status = CaseStatus.Closed
        caseItem.closureDate = closureDate
        dbHelper?.updateCaseStatus(reference, CaseStatus.Closed.name, closureDate)
        dbHelper?.logAudit("Closed case: $reference")
        return true
    }

    fun getAssignedCount(): Int = cases.count { it.status == CaseStatus.Assigned }
    fun getOpenCount(): Int = cases.count { it.status == CaseStatus.Open }
    fun getResolvedCount(): Int = cases.count { it.status == CaseStatus.Resolved }
    fun getClosedCount(): Int = cases.count { it.status == CaseStatus.Closed }
}
