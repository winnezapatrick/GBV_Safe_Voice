package com.example.gbvapp.data.firebase

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

object OfficerAdminRepository {

    suspend fun listAllOfficers(): List<OfficerProfile> {
        return try {
            val snapshot = FirebaseManager.firestore
                .collection("officers")
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                val uid = doc.id
                val data = doc.data ?: return@mapNotNull null
                val name = data["name"] as? String ?: data["fullName"] as? String ?: ""
                val email = data["email"] as? String ?: ""
                val statusStr = data["status"] as? String ?: data["accountStatus"] as? String
                val roleStr = data["role"] as? String
                val dept = data["department"] as? String ?: "Student Support & Safety"
                val createdAt = data["createdAt"]

                OfficerProfile(
                    uid = uid,
                    name = name,
                    email = email,
                    status = OfficerStatus.fromString(statusStr),
                    role = OfficerRole.fromString(roleStr),
                    department = dept,
                    createdAt = createdAt
                )
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            emptyList()
        }
    }

    suspend fun approve(uid: String): Boolean {
        return try {
            FirebaseManager.firestore
                .collection("officers")
                .document(uid)
                .update("status", OfficerStatus.APPROVED.value)
                .await()
            true
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            false
        }
    }

    suspend fun disable(uid: String): Boolean {
        return try {
            FirebaseManager.firestore
                .collection("officers")
                .document(uid)
                .update("status", OfficerStatus.DISABLED.value)
                .await()
            true
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            false
        }
    }
}
