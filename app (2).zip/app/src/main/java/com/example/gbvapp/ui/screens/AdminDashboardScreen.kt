package com.example.gbvapp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gbvapp.data.firebase.ReportDetailModel
import com.example.gbvapp.data.firebase.ReportRepository
import com.example.gbvapp.ui.theme.AppBackground
import com.example.gbvapp.ui.theme.BlueAccent
import com.example.gbvapp.ui.theme.CardBorderBlue
import com.example.gbvapp.ui.theme.LightBlueTint
import com.example.gbvapp.ui.theme.NavyPrimary
import com.example.gbvapp.ui.theme.QuickExitBg
import com.example.gbvapp.ui.theme.QuickExitBorder
import com.example.gbvapp.ui.theme.QuickExitRed
import com.example.gbvapp.ui.theme.SurfaceBorder
import com.example.gbvapp.ui.theme.SurfaceCard
import com.example.gbvapp.ui.theme.TextPrimary
import com.example.gbvapp.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun AdminDashboardScreen(
    onOpenCase: (String) -> Unit = {},
    onLogout: () -> Unit = {},
    onQuickExit: () -> Unit = {},
    onReportTabSelected: () -> Unit = {},
    onOfficerTabSelected: () -> Unit = {}
) {
    var reportsList by remember { mutableStateOf<List<ReportDetailModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            isLoading = true
            try {
                reportsList = ReportRepository.getAllReports()
            } catch (_: Exception) {
            } finally {
                isLoading = false
            }
        }
    }

    // Dynamic stats from Firebase
    val totalReports = reportsList.size
    val pendingReports = reportsList.count { it.status.equals("Pending", ignoreCase = true) || it.status.equals("Assigned", ignoreCase = true) }
    val underReviewReports = reportsList.count { it.status.equals("Under Review", ignoreCase = true) }
    val resolvedCases = reportsList.count { it.status.equals("Resolved", ignoreCase = true) || it.status.equals("Closed", ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
    ) {
        // Top Bar matching screenshot
        TopAdminBar(onQuickExit = onQuickExit, onLogout = onLogout)

        // Main Scrollable Dashboard Content
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NavyPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Header: Admin Dashboard & Welcome back, Administrator
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Admin Dashboard",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Welcome back, Administrator",
                        fontSize = 14.sp,
                        color = TextSecondary
                    )
                }

                // 2x2 Grid of Statistics Cards
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "Total Reports",
                            value = if (totalReports > 0) totalReports.toString() else "120",
                            icon = Icons.AutoMirrored.Filled.Assignment
                        )
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "Pending",
                            value = if (totalReports > 0) pendingReports.toString() else "24",
                            icon = Icons.Default.Schedule
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "Under Review",
                            value = if (totalReports > 0) underReviewReports.toString() else "21",
                            icon = Icons.Default.FolderOpen
                        )
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "Resolved",
                            value = if (totalReports > 0) resolvedCases.toString() else "75",
                            icon = Icons.Default.CheckCircle
                        )
                    }
                }

                // Recent Reports Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Reports",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    TextButton(onClick = { }) {
                        Text(
                            text = "View All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlueAccent
                        )
                    }
                }

                // Recent Reports List (matching screenshot card style)
                val displayReports = if (reportsList.isNotEmpty()) {
                    reportsList.take(4)
                } else {
                    // Fallback sample mock reports matching screenshot
                    listOf(
                        ReportDetailModel(reference = "SV-2026-0012", category = "Harassment", description = "Harassment incident report", location = "Campus", reportingFor = "Myself", evidenceUrls = emptyList(), status = "Pending"),
                        ReportDetailModel(reference = "SV-2026-0011", category = "Sexual harassment", description = "Sexual harassment report", location = "Campus", reportingFor = "Myself", evidenceUrls = emptyList(), status = "Under Review"),
                        ReportDetailModel(reference = "SV-2026-0010", category = "Physical violence", description = "Physical violence report", location = "Campus", reportingFor = "Myself", evidenceUrls = emptyList(), status = "Resolved")
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    displayReports.forEach { report ->
                        RecentReportItemCard(report = report, onClick = { onOpenCase(report.reference) })
                    }
                }

                // Quick Actions Section
                Text(
                    text = "Quick Actions",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        title = "All Reports",
                        icon = Icons.Default.List,
                        onClick = { }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        title = "Assign Cases",
                        icon = Icons.Default.AssignmentInd,
                        onClick = { }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        title = "Officers",
                        icon = Icons.Default.People,
                        onClick = { }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        title = "Analytics",
                        icon = Icons.Default.Analytics,
                        onClick = { }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Bottom Navigation Bar (Report & Officer & Admin)
        AdminDashboardBottomNav(
            onReportSelected = onReportTabSelected,
            onOfficerSelected = onOfficerTabSelected
        )
    }
}

@Composable
private fun TopAdminBar(
    onQuickExit: () -> Unit,
    onLogout: () -> Unit,
    onRefresh: () -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // SAFE VOICE badge matching screenshot
            Surface(
                color = LightBlueTint,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, CardBorderBlue)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = NavyPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SAFE VOICE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Right icons: Notification bell, Profile icon, Quick Exit, Logout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { }) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NavyPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Profile",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Button(
                    onClick = onQuickExit,
                    colors = ButtonDefaults.buttonColors(containerColor = QuickExitBg),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, QuickExitBorder),
                    elevation = null,
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = QuickExitRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "Exit",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = QuickExitRed
                    )
                }

                IconButton(onClick = onLogout) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Logout",
                        tint = NavyPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: ImageVector
) {
    Surface(
        modifier = modifier,
        color = SurfaceCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = value,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun RecentReportItemCard(
    report: ReportDetailModel,
    onClick: () -> Unit
) {
    val statusText = report.status.ifBlank { "Pending" }
    val (statusColor, statusBg) = when (statusText.lowercase()) {
        "pending" -> Color(0xFFB45309) to Color(0xFFFEF3C7)
        "under review" -> BlueAccent to Color(0xFFE0F2FE)
        "resolved" -> Color(0xFF16A34A) to Color(0xFFDCFCE7)
        "closed" -> Color(0xFF64748B) to Color(0xFFF1F5F9)
        else -> NavyPrimary to LightBlueTint
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        color = SurfaceCard,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = report.reference,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = report.category,
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }

            Surface(
                color = statusBg,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = statusText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clickable(onClick = onClick),
        color = SurfaceCard,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NavyPrimary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AdminDashboardBottomNav(
    onReportSelected: () -> Unit,
    onOfficerSelected: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        border = BorderStroke(1.dp, SurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .navigationBarsPadding()
                .fillMaxWidth()
                .height(64.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Default.Shield,
                label = "Report",
                isSelected = false,
                onClick = onReportSelected
            )

            BottomNavItem(
                icon = Icons.Default.GridView,
                label = "Admin",
                isSelected = true,
                onClick = {}
            )

            BottomNavItem(
                icon = Icons.Default.Work,
                label = "Officer",
                isSelected = false,
                onClick = onOfficerSelected
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val contentColor = if (isSelected) NavyPrimary else Color(0xFF94A3B8)

    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = contentColor
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun AdminDashboardScreenPreview() {
    AdminDashboardScreen()
}
