package com.example.gbvapp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gbvapp.data.firebase.AuthRepository
import com.example.gbvapp.data.firebase.CaseManagementRepository
import com.example.gbvapp.data.firebase.CaseNote
import com.example.gbvapp.data.firebase.CaseReferral
import com.example.gbvapp.data.firebase.CurrentOfficer
import com.example.gbvapp.data.firebase.OfficerRole
import com.example.gbvapp.data.firebase.ReportDetailModel
import com.example.gbvapp.data.firebase.ReportRepository
import com.example.gbvapp.ui.theme.AppBackground
import com.example.gbvapp.ui.theme.BlueAccent
import com.example.gbvapp.ui.theme.LightBlueTint
import com.example.gbvapp.ui.theme.NavyPrimary
import com.example.gbvapp.ui.theme.QuickExitBg
import com.example.gbvapp.ui.theme.QuickExitBorder
import com.example.gbvapp.ui.theme.QuickExitRed
import com.example.gbvapp.ui.theme.SurfaceBorder
import com.example.gbvapp.ui.theme.SurfaceCard
import com.example.gbvapp.ui.theme.TextPrimary
import com.example.gbvapp.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun OfficerDashboardScreen(
    onOpenCase: (String) -> Unit = {},
    onNavigateToApprovals: () -> Unit = {},
    onLogout: () -> Unit = {},
    onReportTabSelected: () -> Unit = {},
    onQuickExit: () -> Unit = {}
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Dashboard, 1: My Cases, 2: Review, 3: Case Notes, 4: Referrals, 5: Profile
    var myAssignedReports by remember { mutableStateOf<List<ReportDetailModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Sub-dialogs
    var selectedReportForNote by remember { mutableStateOf<ReportDetailModel?>(null) }
    var selectedReportForReferral by remember { mutableStateOf<ReportDetailModel?>(null) }

    val scope = rememberCoroutineScope()
    val currentUserId = AuthRepository.getCurrentOfficerId() ?: ""

    fun loadOfficerData() {
        scope.launch {
            isLoading = true
            try {
                myAssignedReports = if (currentUserId.isNotBlank()) {
                    ReportRepository.getAssignedReportsForOfficer(currentUserId)
                } else {
                    ReportRepository.getAllReports()
                }
            } catch (_: Exception) {
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadOfficerData()
    }

    val assignedCount = myAssignedReports.size
    val pendingActionCount = myAssignedReports.count { it.status.equals("Assigned", ignoreCase = true) || it.status.equals("Pending", ignoreCase = true) }
    val underReviewCount = myAssignedReports.count { it.status.equals("Under Review", ignoreCase = true) }
    val resolvedCount = myAssignedReports.count { it.status.equals("Resolved", ignoreCase = true) || it.status.equals("Closed", ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
    ) {
        // Top Header Bar
        TopOfficerDashboardHeader(
            onQuickExit = onQuickExit,
            onLogout = onLogout
        )

        // Navigation Tabs Row
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = SurfaceCard,
            contentColor = NavyPrimary
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Dashboard", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("My Cases", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Review", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Case Notes", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Referrals", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
        }

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NavyPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    0 -> OfficerOverviewTab(
                        assignedCount = assignedCount,
                        pendingCount = pendingActionCount,
                        reviewCount = underReviewCount,
                        resolvedCount = resolvedCount,
                        reports = myAssignedReports,
                        onOpenCase = onOpenCase,
                        onNavigateToApprovals = onNavigateToApprovals
                    )
                    1 -> OfficerMyCasesTab(reports = myAssignedReports, onOpenCase = onOpenCase)
                    2 -> OfficerReviewTab(reports = myAssignedReports, onOpenCase = onOpenCase)
                    3 -> OfficerCaseNotesTab(
                        reports = myAssignedReports,
                        onAddNote = { report -> selectedReportForNote = report }
                    )
                    4 -> OfficerReferralsTab(
                        reports = myAssignedReports,
                        onAddReferral = { report -> selectedReportForReferral = report }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Bottom Navigation Bar
        OfficerBottomNavigationBar(
            selectedTab = 1,
            onTabSelected = { tab ->
                if (tab == 0) onReportTabSelected()
            }
        )
    }

    // Add Note Dialog
    if (selectedReportForNote != null) {
        val report = selectedReportForNote!!
        var noteText by remember { mutableStateOf("") }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedReportForNote = null },
            title = { Text("Add Case Note for ${report.reference}", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Confidential Case Observation / Action Note") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteText.isNotBlank()) {
                            isSaving = true
                            scope.launch {
                                CaseManagementRepository.addCaseNote(
                                    reference = report.reference,
                                    noteText = noteText,
                                    authorId = currentUserId,
                                    authorName = CurrentOfficer.profile?.name ?: "Officer"
                                )
                                isSaving = false
                                selectedReportForNote = null
                                loadOfficerData()
                            }
                        }
                    },
                    enabled = !isSaving,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("Save Note", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedReportForNote = null }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

    // Add Referral Dialog
    if (selectedReportForReferral != null) {
        val report = selectedReportForReferral!!
        var referralType by remember { mutableStateOf("Counseling Support") }
        var targetDept by remember { mutableStateOf("University Health & Counseling Center") }
        var refNotes by remember { mutableStateOf("") }
        var isSaving by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { selectedReportForReferral = null },
            title = { Text("Record Support Referral for ${report.reference}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = referralType, onValueChange = { referralType = it }, label = { Text("Referral Type (e.g., Counseling, Legal Aid, Medical)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = targetDept, onValueChange = { targetDept = it }, label = { Text("Target Department / Service Provider") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = refNotes, onValueChange = { refNotes = it }, label = { Text("Referral Notes / Instructions") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (referralType.isNotBlank() && targetDept.isNotBlank()) {
                            isSaving = true
                            scope.launch {
                                CaseManagementRepository.addReferral(
                                    reference = report.reference,
                                    referralType = referralType,
                                    targetDepartment = targetDept,
                                    notes = refNotes,
                                    officerId = currentUserId,
                                    officerName = CurrentOfficer.profile?.name ?: "Officer"
                                )
                                isSaving = false
                                selectedReportForReferral = null
                                loadOfficerData()
                            }
                        }
                    },
                    enabled = !isSaving,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("Record Referral", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedReportForReferral = null }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}

@Composable
private fun OfficerOverviewTab(
    assignedCount: Int,
    pendingCount: Int,
    reviewCount: Int,
    resolvedCount: Int,
    reports: List<ReportDetailModel>,
    onOpenCase: (String) -> Unit,
    onNavigateToApprovals: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Officer Investigation Dashboard",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Welcome, Officer ${CurrentOfficer.profile?.name ?: "Bunda"}. Active case overview.",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            if (CurrentOfficer.profile?.role == OfficerRole.ADMIN) {
                Button(
                    onClick = onNavigateToApprovals,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Officer Approvals", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // 4 Summary Stat Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OfficerStatCard(modifier = Modifier.weight(1f), value = assignedCount.toString(), label = "Assigned", containerColor = Color(0xFFE0F2FE), textColor = NavyPrimary, icon = Icons.AutoMirrored.Filled.Assignment, badgeColor = BlueAccent)
            OfficerStatCard(modifier = Modifier.weight(1f), value = pendingCount.toString(), label = "Pending Action", containerColor = Color(0xFFFEF3C7), textColor = Color(0xFFB45309), icon = Icons.Default.FolderOpen, badgeColor = Color(0xFFB45309))
            OfficerStatCard(modifier = Modifier.weight(1f), value = reviewCount.toString(), label = "Under Review", containerColor = Color(0xFFEFF6FF), textColor = NavyPrimary, icon = Icons.Default.RateReview, badgeColor = BlueAccent)
            OfficerStatCard(modifier = Modifier.weight(1f), value = resolvedCount.toString(), label = "Resolved", containerColor = Color(0xFFDCFCE7), textColor = Color(0xFF16A34A), icon = Icons.Default.CheckCircle, badgeColor = Color(0xFF16A34A))
        }

        Text("Assigned Cases Queue", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

        if (reports.isEmpty()) {
            Text("No active cases assigned to your account.", fontSize = 13.sp, color = TextSecondary)
        } else {
            reports.forEach { report ->
                OfficerReportCard(report = report, onOpen = { onOpenCase(report.reference) })
            }
        }
    }
}

@Composable
private fun OfficerMyCasesTab(reports: List<ReportDetailModel>, onOpenCase: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My Authorized Assigned Cases (${reports.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (reports.isEmpty()) {
            Text("No cases assigned to your account.", fontSize = 13.sp, color = TextSecondary)
        } else {
            reports.forEach { report ->
                OfficerReportCard(report = report, onOpen = { onOpenCase(report.reference) })
            }
        }
    }
}

@Composable
private fun OfficerReviewTab(reports: List<ReportDetailModel>, onOpenCase: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Case Assessment & Seriousness Review", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (reports.isEmpty()) {
            Text("No reports pending review.", fontSize = 13.sp, color = TextSecondary)
        } else {
            reports.forEach { report ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SurfaceCard,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(report.reference, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Urgency: ${report.urgencyLevel}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                        }
                        Text(report.category, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(report.description, fontSize = 12.sp, color = TextSecondary, maxLines = 2)
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(onClick = { onOpenCase(report.reference) }, colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)) {
                            Text("Review Observations & Open File", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OfficerCaseNotesTab(
    reports: List<ReportDetailModel>,
    onAddNote: (ReportDetailModel) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Confidential Case Notes & Progress Updates", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (reports.isEmpty()) {
            Text("No cases available for adding notes.", fontSize = 13.sp, color = TextSecondary)
        } else {
            reports.forEach { report ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SurfaceCard,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(report.reference, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(report.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                        }
                        Text(report.category, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Button(onClick = { onAddNote(report) }, colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)) {
                            Icon(Icons.Default.NoteAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Case Note", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OfficerReferralsTab(
    reports: List<ReportDetailModel>,
    onAddReferral: (ReportDetailModel) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Student Support & Departmental Referrals", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (reports.isEmpty()) {
            Text("No cases available for student support referrals.", fontSize = 13.sp, color = TextSecondary)
        } else {
            reports.forEach { report ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SurfaceCard,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(report.reference, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(report.category, fontSize = 12.sp, color = TextSecondary)
                        }
                        Button(onClick = { onAddReferral(report) }, colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)) {
                            Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Record Student Support Referral", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopOfficerDashboardHeader(
    onQuickExit: () -> Unit,
    onLogout: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceCard,
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Box(
                        modifier = Modifier.padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SafeVoiceLogoIcon(modifier = Modifier.fillMaxSize())
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = "FIELD INVESTIGATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Officer Portal",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onQuickExit,
                    colors = ButtonDefaults.buttonColors(containerColor = QuickExitBg),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, QuickExitBorder),
                    elevation = null,
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = QuickExitRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Exit",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = QuickExitRed
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(onClick = onLogout) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Logout",
                        tint = NavyPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun OfficerStatCard(
    modifier: Modifier = Modifier,
    value: String,
    label: String,
    containerColor: Color,
    textColor: Color,
    icon: ImageVector,
    badgeColor: Color
) {
    Surface(
        modifier = modifier,
        color = containerColor,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = badgeColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun OfficerReportCard(
    report: ReportDetailModel,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = NavyPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = report.reference,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Surface(
                    color = Color(0xFFE0F2FE),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = report.status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Text(
                text = report.category,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = report.location,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onOpen,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "OPEN CASE DETAILS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun OfficerBottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        border = BorderStroke(1.dp, SurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .navigationBarsPadding()
                .fillMaxWidth()
                .height(64.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OfficerBottomNavItem(
                icon = Icons.Default.Shield,
                label = "Report",
                isSelected = selectedTab == 0,
                onClick = { onTabSelected(0) }
            )

            OfficerBottomNavItem(
                icon = Icons.Default.Work,
                label = "Officer",
                isSelected = selectedTab == 1,
                onClick = { onTabSelected(1) }
            )
        }
    }
}

@Composable
private fun OfficerBottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val contentColor = if (isSelected) NavyPrimary else Color(0xFF94A3B8)

    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = contentColor
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun OfficerDashboardScreenPreview() {
    OfficerDashboardScreen()
}
