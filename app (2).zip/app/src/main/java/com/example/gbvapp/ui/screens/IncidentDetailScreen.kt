package com.example.gbvapp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.gbvapp.data.CaseItem
import com.example.gbvapp.data.CaseRepository
import com.example.gbvapp.data.CaseStatus
import com.example.gbvapp.data.firebase.AuthRepository
import com.example.gbvapp.data.firebase.CaseManagementRepository
import com.example.gbvapp.data.firebase.CaseNote
import com.example.gbvapp.data.firebase.CaseReferral
import com.example.gbvapp.data.firebase.CurrentOfficer
import com.example.gbvapp.ui.theme.AppBackground
import com.example.gbvapp.ui.theme.BlueAccent
import com.example.gbvapp.ui.theme.LightBlueTint
import com.example.gbvapp.ui.theme.NavyPrimary
import com.example.gbvapp.ui.theme.QuickExitBg
import com.example.gbvapp.ui.theme.QuickExitBorder
import com.example.gbvapp.ui.theme.QuickExitRed
import com.example.gbvapp.ui.theme.SurfaceBorder
import com.example.gbvapp.ui.theme.SurfaceCard
import com.example.gbvapp.ui.theme.TextPrimary
import com.example.gbvapp.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun IncidentDetailScreen(
    caseReference: String = "GBV-2026-0047",
    onBack: () -> Unit = {},
    onQuickExit: () -> Unit = {}
) {
    var caseItem by remember { mutableStateOf(CaseRepository.cases.find { it.reference == caseReference } ?: CaseRepository.cases.first()) }
    var caseNotes by remember { mutableStateOf<List<CaseNote>>(emptyList()) }
    var caseReferrals by remember { mutableStateOf<List<CaseReferral>>(emptyList()) }

    var showCloseDialog by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var showAddReferralDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val currentUserId = AuthRepository.getCurrentOfficerId() ?: ""

    fun loadDetailRecords() {
        scope.launch {
            caseNotes = CaseManagementRepository.getCaseNotes(caseReference)
            caseReferrals = CaseManagementRepository.getReferrals(caseReference)
        }
    }

    LaunchedEffect(caseReference) {
        loadDetailRecords()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppBackground)
    ) {
        // Top Header Bar
        TopCaseHeaderBar(
            onBack = onBack,
            onQuickExit = onQuickExit
        )

        // Main Scrollable Content
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Badges & Incident Ref Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge(text = caseItem.status.name.uppercase(), containerColor = Color(0xFFE0F2FE), textColor = NavyPrimary)
                StatusBadge(text = "100% Anonymous Submission", containerColor = Color(0xFFFEF3C7), textColor = Color(0xFFB45309))
                StatusBadge(text = "Confidential", containerColor = Color(0xFFFEE2E2), textColor = Color(0xFFDC2626))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INCIDENT REF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = caseItem.reference,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Surface(
                    color = LightBlueTint,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = BlueAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Encrypted Intake",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    }
                }
            }

            // Incident Category Card
            DetailCard(title = "Incident Category") {
                Text(
                    text = caseItem.category,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            // Date & Time / Reported Date
            DetailCard(title = "Submission & Incident Date") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Submitted: ${caseItem.submissionDate}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Reported: ${caseItem.dateReported}",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        if (caseItem.closureDate != null) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Closed on: ${caseItem.closureDate}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }

            // Location Card
            DetailCard(title = "Incident Location") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = caseItem.location,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                }
            }

            // Description Card
            DetailCard(title = "Incident Description (Anonymous)") {
                Text(
                    text = caseItem.description,
                    fontSize = 13.sp,
                    color = TextPrimary,
                    lineHeight = 18.sp
                )
            }

            // Evidence Attachments Card
            DetailCard(title = "Evidence Attachments") {
                if (caseItem.evidenceAttachments.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        caseItem.evidenceAttachments.forEach { attachment ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = null,
                                    tint = NavyPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = attachment,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NavyPrimary
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "No evidence files attached.",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            }

            // Case Notes Card Section
            DetailCard(title = "Confidential Case Notes (${caseNotes.size})") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (caseNotes.isEmpty()) {
                        Text("No case notes recorded yet.", fontSize = 12.sp, color = TextSecondary)
                    } else {
                        caseNotes.forEach { note ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = LightBlueTint,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(note.noteText, fontSize = 13.sp, color = TextPrimary)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("By: ${note.authorName}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { showAddNoteDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Case Note", fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            // Student Referrals Card Section
            DetailCard(title = "Student Support & Referrals (${caseReferrals.size})") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (caseReferrals.isEmpty()) {
                        Text("No support referrals recorded yet.", fontSize = 12.sp, color = TextSecondary)
                    } else {
                        caseReferrals.forEach { ref ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("${ref.referralType} -> ${ref.targetDepartment}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                    if (ref.notes.isNotBlank()) {
                                        Text(ref.notes, fontSize = 12.sp, color = TextPrimary)
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { showAddReferralDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Record Support Referral", fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Prominent Close Case Button or Closed Notice
            if (caseItem.status == CaseStatus.Closed) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "This case is formally CLOSED",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Closed on: ${caseItem.closureDate ?: "N/A"}",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                Button(
                    onClick = { showCloseDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(
                        text = "CLOSE CASE",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Add Note Dialog
    if (showAddNoteDialog) {
        var noteText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddNoteDialog = false },
            title = { Text("Add Confidential Note", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Case handling note / observation") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteText.isNotBlank()) {
                            scope.launch {
                                CaseManagementRepository.addCaseNote(
                                    reference = caseItem.reference,
                                    noteText = noteText,
                                    authorId = currentUserId,
                                    authorName = CurrentOfficer.profile?.name ?: "Officer"
                                )
                                showAddNoteDialog = false
                                loadDetailRecords()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) { Text("Save Note", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoteDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

    // Add Referral Dialog
    if (showAddReferralDialog) {
        var refType by remember { mutableStateOf("Counseling Support") }
        var dept by remember { mutableStateOf("University Health & Counseling Services") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddReferralDialog = false },
            title = { Text("Record Support Referral", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = refType, onValueChange = { refType = it }, label = { Text("Referral Type") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = dept, onValueChange = { dept = it }, label = { Text("Department / Provider") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Referral Notes") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (refType.isNotBlank() && dept.isNotBlank()) {
                            scope.launch {
                                CaseManagementRepository.addReferral(
                                    reference = caseItem.reference,
                                    referralType = refType,
                                    targetDepartment = dept,
                                    notes = notes,
                                    officerId = currentUserId,
                                    officerName = CurrentOfficer.profile?.name ?: "Officer"
                                )
                                showAddReferralDialog = false
                                loadDetailRecords()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) { Text("Record Referral", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { showAddReferralDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

    // Confirmation Dialog for Closing Case
    if (showCloseDialog) {
        AlertDialog(
            onDismissRequest = { showCloseDialog = false },
            title = {
                Text(text = "Close Case", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(text = "Are you sure you want to close this case?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val officerId = AuthRepository.getCurrentOfficerId()
                        if (officerId != null) {
                            scope.launch {
                                CaseManagementRepository.updateCaseStatus(caseItem.reference, "Closed", officerId)
                            }
                        }
                        val dateFormat = SimpleDateFormat("dd/MM/yyyy, HH:mm", Locale.getDefault())
                        val currentTime = dateFormat.format(Date())
                        caseItem.status = CaseStatus.Closed
                        caseItem.closureDate = currentTime
                        showCloseDialog = false
                    }
                ) {
                    Text(text = "Confirm Close", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCloseDialog = false }
                ) {
                    Text(text = "Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun TopCaseHeaderBar(
    onBack: () -> Unit,
    onQuickExit: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = NavyPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Column {
                    Text(
                        text = "CASE FILE REVIEW",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Confidential Details",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            Button(
                onClick = onQuickExit,
                colors = ButtonDefaults.buttonColors(containerColor = QuickExitBg),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, QuickExitBorder),
                elevation = null,
                modifier = Modifier.height(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = QuickExitRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Exit",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = QuickExitRed
                )
            }
        }
    }
}

@Composable
private fun StatusBadge(
    text: String,
    containerColor: Color,
    textColor: Color
) {
    Surface(
        color = containerColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun DetailCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = SurfaceCard,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SurfaceBorder),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
            content()
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun IncidentDetailScreenPreview() {
    IncidentDetailScreen()
}
