package com.example.gbvapp.data.firebase

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await

data class CaseNote(
    val reference: String,
    val noteText: String,
    val authorId: String,
    val authorName: String,
    val timestamp: Any = FieldValue.serverTimestamp()
)

data class CaseReferral(
    val reference: String,
    val referralType: String, // Counseling, Healthcare, Legal Aid, Student Affairs
    val targetDepartment: String,
    val notes: String,
    val officerId: String,
    val officerName: String,
    val timestamp: Any = FieldValue.serverTimestamp()
)

data class AuditLogRecord(
    val id: String = "",
    val action: String,
    val category: String,
    val performedBy: String,
    val targetId: String,
    val details: String,
    val timestamp: Any = FieldValue.serverTimestamp()
)

object CaseManagementRepository {

    suspend fun updateCaseStatus(reference: String, newStatus: String, officerId: String): Boolean {
        return try {
            val firestore = FirebaseManager.firestore
            
            val updates = mutableMapOf<String, Any>(
                "status" to newStatus,
                "lastUpdatedAt" to FieldValue.serverTimestamp()
            )
            if (newStatus == "Closed") {
                updates["closureDate"] = FieldValue.serverTimestamp()
            }

            firestore.collection("reports")
                .document(reference)
                .update(updates)
                .await()

            val updateRecord = hashMapOf(
                "reference" to reference,
                "status" to newStatus,
                "updatedBy" to officerId,
                "timestamp" to FieldValue.serverTimestamp()
            )

            firestore.collection("caseUpdates")
                .add(updateRecord)
                .await()

            logAudit(
                action = "CASE_STATUS_UPDATED",
                category = "Case Management",
                performedBy = officerId,
                targetId = reference,
                details = "Updated case $reference status to $newStatus."
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun addCaseNote(reference: String, noteText: String, authorId: String, authorName: String): Boolean {
        return try {
            val noteData = hashMapOf(
                "reference" to reference,
                "noteText" to noteText,
                "authorId" to authorId,
                "authorName" to authorName,
                "timestamp" to FieldValue.serverTimestamp()
            )

            FirebaseManager.firestore.collection("caseNotes")
                .add(noteData)
                .await()

            logAudit(
                action = "CASE_NOTE_ADDED",
                category = "Case Management",
                performedBy = authorName,
                targetId = reference,
                details = "Added confidential note to case $reference."
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getCaseNotes(reference: String): List<CaseNote> {
        return try {
            val snapshot = FirebaseManager.firestore.collection("caseNotes")
                .whereEqualTo("reference", reference)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                val ref = doc.getString("reference") ?: reference
                val text = doc.getString("noteText") ?: ""
                val authId = doc.getString("authorId") ?: ""
                val authName = doc.getString("authorName") ?: "Officer"
                val ts = doc.get("timestamp") ?: ""

                CaseNote(
                    reference = ref,
                    noteText = text,
                    authorId = authId,
                    authorName = authName,
                    timestamp = ts
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun addReferral(
        reference: String,
        referralType: String,
        targetDepartment: String,
        notes: String,
        officerId: String,
        officerName: String
    ): Boolean {
        return try {
            val referralData = hashMapOf(
                "reference" to reference,
                "referralType" to referralType,
                "targetDepartment" to targetDepartment,
                "notes" to notes,
                "officerId" to officerId,
                "officerName" to officerName,
                "timestamp" to FieldValue.serverTimestamp()
            )

            FirebaseManager.firestore.collection("referrals")
                .add(referralData)
                .await()

            logAudit(
                action = "CASE_REFERRAL_RECORDED",
                category = "Support & Referrals",
                performedBy = officerName,
                targetId = reference,
                details = "Recorded $referralType referral to $targetDepartment for case $reference."
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getReferrals(reference: String): List<CaseReferral> {
        return try {
            val snapshot = FirebaseManager.firestore.collection("referrals")
                .whereEqualTo("reference", reference)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                val ref = doc.getString("reference") ?: reference
                val type = doc.getString("referralType") ?: "Support Service"
                val dept = doc.getString("targetDepartment") ?: "Counseling"
                val notes = doc.getString("notes") ?: ""
                val offId = doc.getString("officerId") ?: ""
                val offName = doc.getString("officerName") ?: "Officer"
                val ts = doc.get("timestamp") ?: ""

                CaseReferral(
                    reference = ref,
                    referralType = type,
                    targetDepartment = dept,
                    notes = notes,
                    officerId = offId,
                    officerName = offName,
                    timestamp = ts
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun logAudit(
        action: String,
        category: String,
        performedBy: String,
        targetId: String,
        details: String
    ) {
        try {
            val auditData = hashMapOf(
                "action" to action,
                "category" to category,
                "performedBy" to performedBy,
                "targetId" to targetId,
                "details" to details,
                "timestamp" to FieldValue.serverTimestamp()
            )

            FirebaseManager.firestore.collection("auditLogs")
                .add(auditData)
                .await()
        } catch (_: Exception) {}
    }

    suspend fun getAuditLogs(): List<AuditLogRecord> {
        return try {
            val snapshot = FirebaseManager.firestore.collection("auditLogs")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50)
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                val action = doc.getString("action") ?: "SYSTEM_ACTION"
                val category = doc.getString("category") ?: "General"
                val performedBy = doc.getString("performedBy") ?: "System"
                val targetId = doc.getString("targetId") ?: ""
                val details = doc.getString("details") ?: ""
                val ts = doc.get("timestamp") ?: ""

                AuditLogRecord(
                    id = doc.id,
                    action = action,
                    category = category,
                    performedBy = performedBy,
                    targetId = targetId,
                    details = details,
                    timestamp = ts
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
