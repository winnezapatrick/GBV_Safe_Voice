package com.example.gbvapp

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.gbvapp.data.CaseItem
import com.example.gbvapp.data.CaseRepository
import com.example.gbvapp.data.CaseStatus
import com.example.gbvapp.data.firebase.AuthRepository
import com.example.gbvapp.data.firebase.CurrentOfficer
import com.example.gbvapp.data.firebase.OfficerRole
import com.example.gbvapp.data.firebase.ReportRepository
import com.example.gbvapp.ui.screens.AdminDashboardScreen
import com.example.gbvapp.ui.screens.FinalScreen
import com.example.gbvapp.ui.screens.IncidentCategoryScreen
import com.example.gbvapp.ui.screens.IncidentDetailScreen
import com.example.gbvapp.ui.screens.OfficerDashboardScreen
import com.example.gbvapp.ui.screens.OfficerLoginScreen
import com.example.gbvapp.ui.screens.ReportInformationScreen
import com.example.gbvapp.ui.screens.SubmissionScreen
import com.example.gbvapp.ui.screens.WelcomeScreen
import com.example.gbvapp.ui.theme.GBVAPPTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CaseRepository.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            GBVAPPTheme {
                MainAppContent()
            }
        }
    }
}

@Composable
fun MainAppContent() {
    var currentScreen by remember { mutableStateOf("welcome") }
    var selectedCaseRef by remember { mutableStateOf("GBV-2026-0047") }
    var reportCategory by remember { mutableStateOf("Sexual Harassment") }
    var reportDescription by remember { mutableStateOf("") }
    var reportEvidenceUris by remember { mutableStateOf<List<Uri>>(emptyList()) }

    Surface(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            "welcome" -> WelcomeScreen(
                onProceedToReport = { currentScreen = "step1" },
                onOfficerTabSelected = { currentScreen = "officer_login" },
                onQuickExit = { currentScreen = "welcome" }
            )
            "step1" -> ReportInformationScreen(
                onBack = { currentScreen = "welcome" },
                onProceedToDetails = { currentScreen = "step2" },
                onQuickExit = { currentScreen = "welcome" }
            )
            "step2" -> IncidentCategoryScreen(
                onBack = { currentScreen = "step1" },
                onSubmitReport = { category, description, uris ->
                    reportCategory = category
                    reportDescription = description
                    reportEvidenceUris = uris
                    currentScreen = "step3"
                },
                onQuickExit = { currentScreen = "welcome" }
            )
            "step3" -> SubmissionScreen(
                selectedCategory = reportCategory,
                onBack = { currentScreen = "step2" },
                onSubmitFinalReport = {
                    val scope = CoroutineScope(Dispatchers.IO)
                    scope.launch {
                        try {
                            ReportRepository.submitReport(
                                category = reportCategory,
                                description = reportDescription.ifBlank { "User submitted incident report." },
                                location = "Zomba Central, Near District Hospital Market",
                                reportingFor = "Myself",
                                evidenceUris = reportEvidenceUris
                            )
                        } catch (_: Exception) {}
                    }
                    val newCase = CaseItem(
                        reference = "GBV-2026-" + (1000..9999).random(),
                        category = reportCategory,
                        location = "Zomba Central, Near District Hospital Market",
                        dateReported = "Today, 14:30",
                        description = reportDescription.ifBlank { "User submitted incident report." },
                        evidenceAttachments = reportEvidenceUris.map { it.lastPathSegment ?: "evidence_file.jpg" }.ifEmpty { listOf("photo_evidence_01.jpg") },
                        status = CaseStatus.Assigned,
                        submissionDate = "Today, 14:30"
                    )
                    CaseRepository.addCase(newCase)
                    selectedCaseRef = newCase.reference
                    currentScreen = "final"
                },
                onQuickExit = { currentScreen = "welcome" }
            )
            "final" -> FinalScreen(
                caseCode = selectedCaseRef,
                onDone = { currentScreen = "welcome" },
                onOfficerTabSelected = { currentScreen = "officer_login" },
                onQuickExit = { currentScreen = "welcome" }
            )
            "officer_login" -> OfficerLoginScreen(
                onLoginSuccess = {
                    if (CurrentOfficer.profile?.role == OfficerRole.ADMIN) {
                        currentScreen = "admin_dashboard"
                    } else {
                        currentScreen = "officer_dashboard"
                    }
                },
                onReportTabSelected = { currentScreen = "welcome" }
            )
            "officer_dashboard" -> OfficerDashboardScreen(
                onOpenCase = { ref ->
                    selectedCaseRef = ref
                    currentScreen = "incident"
                },
                onLogout = {
                    AuthRepository.logout()
                    currentScreen = "officer_login"
                },
                onReportTabSelected = { currentScreen = "welcome" },
                onQuickExit = { currentScreen = "welcome" }
            )
            "admin_dashboard" -> AdminDashboardScreen(
                onOpenCase = { ref ->
                    selectedCaseRef = ref
                    currentScreen = "incident"
                },
                onLogout = {
                    AuthRepository.logout()
                    currentScreen = "officer_login"
                },
                onQuickExit = { currentScreen = "welcome" },
                onReportTabSelected = { currentScreen = "welcome" },
                onOfficerTabSelected = { currentScreen = "officer_login" }
            )
            "incident" -> IncidentDetailScreen(
                caseReference = selectedCaseRef,
                onBack = {
                    if (CurrentOfficer.profile?.role == OfficerRole.ADMIN) {
                        currentScreen = "admin_dashboard"
                    } else {
                        currentScreen = "officer_dashboard"
                    }
                },
                onQuickExit = { currentScreen = "welcome" }
            )
        }
    }
}
